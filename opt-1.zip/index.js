function calculateFirst() {
  let a = Number(document.getElementById('input-1').value);
  let b = Number(document.getElementById('input-2').value);
  let c = Number(document.getElementById('input-3').value);

  clearErrors();

  if (isNaN(a)) {
    sendError(1, 'Неверный формат числа!');
    return;
  }
  if (isNaN(b)) {
    sendError(2, 'Неверный формат числа!');
    return;
  }
  if (isNaN(c)) {
    sendError(3, 'Неверный формат числа!');
    return;
  }

  //clear();
  let values = getValues(a,b,c);

  let result;
  if (values.d < 0) {
    result = 'Стартовые значения: <br/>' +
      'a=' + a + ' b=' + b + ' c=' + c + '<br/>' +
      'Дискриминант меньше нуля!';
  }
  if (values.d == 0) {
    result = 'Стартовые значения: <br/>' +
      'a=' + a + ' b=' + b + ' c=' + c + '<br/>' +
      'Дискриминант равен нулю!<br/>' +
      'x= ' + values.x1;
  }
  if (values.d > 0) {
    result = 'Стартовые значения: <br/>' +
      'a=' + a + ' b=' + b + ' c=' + c + '<br/>' +
      'd=' + values.d + '<br/>' +
      'x1= ' + values.x1 + ' x2 = ' + values.x2;
  }

  $('#result').html(result);
}

function sendError(id, text) {
  $('#input-' + id).addClass('error');
  $('#input-log-' + id).html(text);
}

function getValues(a, b, c) {
  let d = b*b - 4*a*c;
  let x1 = d >= 0 ? (-b+Math.sqrt(d))/(2*a) : 0;
  let x2 = d >= 0 ? (-b-Math.sqrt(d))/(2*a) : 0;
  return {
    d: d,
    x1: x1,
    x2: x2,
  };

}

function clear() {
  $('#input-1').val('');
  $('#input-2').val('');
  $('#input-3').val('');
}

function clearErrors() {
  $('#input-1').removeClass('error');
  $('#input-2').removeClass('error');
  $('#input-3').removeClass('error');
  $('#input-log-1').html('');
  $('#input-log-2').html('');
  $('#input-log-3').html('');
}